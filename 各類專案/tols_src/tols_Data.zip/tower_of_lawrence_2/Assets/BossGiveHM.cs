﻿using UnityEngine;
using System.Collections;

public class BossGiveHM : MonoBehaviour {
	public GameObject LKiller;
	public GameObject RKiller;
	public GameObject bigbox;
	GameObject box;
	GameObject firstBox;
	// Use this for initialization
	void Start () {
		StartCoroutine (waitForSeconds ());
		firstBox = (UnityEngine.GameObject)GameObject.Instantiate (bigbox);
	}
	
	// Update is called once per frame
	void Update () {



	}
	IEnumerator waitForSeconds()
	{

		while (true) {
						yield return new WaitForSeconds (10);
			try{GameObject.Destroy(firstBox);}catch(UnityException e){e.GetType();}
						box = (GameObject)GameObject.Instantiate(bigbox);
						yield return new WaitForSeconds (15);
						GameObject.Instantiate (LKiller);
						GameObject.Instantiate (RKiller);
						GameObject.Destroy(box);
						
						
		}
	}
	int rnd(int min, int max){return Random.Range (min, max);}
}

