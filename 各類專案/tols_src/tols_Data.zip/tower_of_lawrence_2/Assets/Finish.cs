﻿using UnityEngine;
using System.Collections;

public class Finish : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	void OnCollisionEnter2D(Collision2D coll)
	{
		if (coll.gameObject.tag == "spear") {
			moving.changeDirection = false;
			androidAxis.changeDirection = false;
			destoryStpr.changeDirection = false;
			Application.LoadLevel("thank");
		}

	}
}
