﻿using UnityEngine;
using System.Collections;

public class randomMoving : MonoBehaviour {
	public Vector2 power;
	// Use this for initialization
	void Start () {
	
	}
	int rnd(int min, int max){return Random.Range (min, max);}
	// Update is called once per frame
	void Update () {
		gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2 (rnd (-(int)power.x, (int)power.x), rnd (-(int)power.y, (int)power.y));
	}
}
