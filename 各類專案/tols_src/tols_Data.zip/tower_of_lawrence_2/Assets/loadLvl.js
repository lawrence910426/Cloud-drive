﻿#pragma strict
var level : String;
function Start () {

}

function Update () {

}

function load()
{
		Application.LoadLevel(level);


}