﻿using UnityEngine;
using System.Collections;

public class moving : MonoBehaviour {
	public float deltaTimes;
	public static bool changeDirection;
	public bool notUseChangeDirection;
	// Use this for initialization
	void Start () {
		
	}

	// Update is called once per frame
	void Update () {
		if (notUseChangeDirection)
						GetComponent<Rigidbody2D>().velocity = new Vector2 ((deltaTimes * Time.deltaTime), GetComponent<Rigidbody2D>().velocity.y);
		else {
			if (changeDirection)
						GetComponent<Rigidbody2D>().velocity = new Vector2 (-(deltaTimes * Time.deltaTime), GetComponent<Rigidbody2D>().velocity.y);
			if (!changeDirection)
						GetComponent<Rigidbody2D>().velocity = new Vector2 ((deltaTimes * Time.deltaTime), GetComponent<Rigidbody2D>().velocity.y);
		}
	}
}
