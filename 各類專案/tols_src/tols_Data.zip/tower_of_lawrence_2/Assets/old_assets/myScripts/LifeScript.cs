using UnityEngine;
using System.Collections;

public class LifeScript : MonoBehaviour {
	public int life;
	public GameObject guitext;
	bool askForDead;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (askForDead)
						Time.timeScale = 0;
				else
						Time.timeScale = 1;
	}
	void OnGUI()
	{ 

		if (askForDead) {
			Time.timeScale = 0;		if (GUI.Button (new Rect (Screen.width - 210, 10, 200,200), "No")) {
				Application.LoadLevel ("GG");
			}//Debug.Log ("aaa");

			if(livesLeft.lifeLeft == 0) return;


			if (GUI.Button (new Rect (10, 10, 200, 200), "ReSpawn")) {
			livesLeft.changing=true;
			livesLeft.lifeLeft--;
			GameObject screenText  = (GameObject)GameObject.Instantiate(guitext);
			screenText.GetComponent<GUIText>().text = livesLeft.lifeLeft.ToString() + " Lives left";
			askForDead = false;
			Time.timeScale = 1;
		}//Debug.Log ("aaa");
		}
	}
	void OnTriggerEnter2D(Collider2D collider)
	{
				if (GameObject.FindGameObjectsWithTag ("Player").Length == 1) {
						askForDead = true;
						//GUI.Button(new Rect(10,10,10,10)
				} else {
					GameObject.Destroy(gameObject);

				}
			GameObject.Destroy(collider.gameObject);
		    
	}

}
