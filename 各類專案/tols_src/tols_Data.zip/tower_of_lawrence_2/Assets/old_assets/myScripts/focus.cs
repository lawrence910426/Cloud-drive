﻿using UnityEngine;
using System.Collections;

public class focus : MonoBehaviour {
	public string scrollName;
	public float MinSize;
	public bool enableScroll;
	// Use this for initialization
	void Start () {
	    
	}
	
	// Update is called once per frame'
	void Update(){
		//this is a bad way to do this program'
		gameObject.transform.position = new Vector3(GameObject.FindGameObjectWithTag ("Player").transform.position.x + 10,GameObject.FindGameObjectWithTag ("Player").transform.position.y,gameObject.transform.position.z);



	}

	void FixedUpdate () {
				//rigidbody2D.velocity = new Vector2 (0, 0);
		if (enableScroll) {
						float i = (Input.GetAxis (scrollName) + GetComponent<Camera>().orthographicSize);
						if (i > MinSize) {
								GetComponent<Camera>().orthographicSize = i;
						}
				}
				//it could be under zero
		        // and it will looks so strange
	}

}
