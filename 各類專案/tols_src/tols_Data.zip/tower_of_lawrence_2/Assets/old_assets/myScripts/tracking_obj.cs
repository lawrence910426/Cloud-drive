﻿using UnityEngine;
using System.Collections;

public class tracking_obj : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		gameObject.GetComponent<Rigidbody2D>() .position = GameObject.FindGameObjectWithTag ("Player").GetComponent<Rigidbody2D>().position;
		Debug.Log (GameObject.FindGameObjectWithTag ("Player").GetComponent<Rigidbody2D>().position.ToString ());
	}
}
