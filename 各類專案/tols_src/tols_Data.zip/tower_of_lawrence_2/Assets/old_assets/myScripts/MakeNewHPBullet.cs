﻿using UnityEngine;
using System.Collections;

public class MakeNewHPBullet : MonoBehaviour {
	public GameObject obj;
	public int waitTimes;
	public string InstanceId;//to avoid make a lot more bullet.(user didn't eat the bullet everytime
	int counter = 0;

	// Use this for initialization
	void Start () {
		try{
		obj.tag = InstanceId;
		}catch{
			Debug.Log("error");
		}
	}
	
	// Update is called once per frame
	void Update () {
		//counter++;

	     if (counter++ == waitTimes) {

			{
//			    try{
//					GameObject.FindGameObjectWithTag(InstanceId);
//
//
//
//				}catch{
//
//				}
				//GameObject.Instantiate (obj);	
				//GameObject.Instantiate(obj ,new Vector2(transform.position.x ,transform.position.y ),Quaternion.identity);

				Instantiate(obj);
				Debug.Log (counter);	
				counter = 0;
			}
		}
	}
}
