﻿using UnityEngine;
using System.Collections;

public class CharactorController : MonoBehaviour {
	public string JumpName;
	public string LRName;
	public float speed;
	public float jumpSpeed;
	public int JumpTimes;
	int JumpTimesCounter;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		GetComponent<Rigidbody2D>().velocity += new Vector2(Input.GetAxis (LRName) * speed ,0);
		Jump ();
	}
	void Jump(){
		if (Input.GetAxis (JumpName) > 0) {
			JumpTimesCounter = JumpTimes;

			
		}
		if (JumpTimesCounter-- > 0) {
			GetComponent<Rigidbody2D>().velocity += new Vector2 (0, 1 * jumpSpeed );
	    } else {
			JumpTimesCounter = 0;

		}
	}
}
