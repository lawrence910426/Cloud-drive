﻿#pragma strict

function Start () {

}


function Update () {
       StartCoroutine("WaitAndPlay");             
       GameObject.Destroy(gameObject);
}

function WaitAndPlay() {
	yield WaitForSeconds(3);
}