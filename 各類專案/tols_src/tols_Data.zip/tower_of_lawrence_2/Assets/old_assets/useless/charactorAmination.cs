﻿using UnityEngine;
using System.Collections;

public class charactorAmination : MonoBehaviour {
	public Sprite[] sprites;
	short onFrame = 0;
	private SpriteRenderer spriteRenderer;
	public int wait = 100;
	int waited;
	// Use this for initialization
	void Start () {
		
		spriteRenderer = GetComponent<Renderer>() as SpriteRenderer;	
		waited = wait;
	}
	
	// Update is called once per frame
	void FixedUpdate () {
		waited -= 1;
		if (waited == 0) {
		   
						try {
								((SpriteRenderer)GetComponent<Renderer>()).sprite = sprites [onFrame++];
								if (onFrame >= sprites.Length)
										onFrame = 0;
						} catch (UnityException ex) {
								Debug.Log (ex.ToString ());
						}
				} else {
						waited = wait;
				}
	}
}
