﻿using UnityEngine;
using System.Collections;
using System.Threading;
public class destoySelf : MonoBehaviour {
	//bool kill = false;
	//Thread t;
	// Use this for initialization
	void Start () {
		//t = new Thread (new ThreadStart (tmr));t.Start ();
	}

	/*IEnumerable timer(){

		kill = true;
	}*/

	// Update is called once per frame
	IEnumerable wait(){
				yield return new WaitForSeconds (10);
		}
	void Update () {
		//
		wait ();
						//t.Abort ();
						GameObject.Destroy (gameObject);

	}
}
