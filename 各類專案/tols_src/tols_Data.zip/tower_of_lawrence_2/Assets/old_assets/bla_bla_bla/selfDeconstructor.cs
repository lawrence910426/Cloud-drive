﻿using UnityEngine;
using System.Collections;
using System.Threading;
public class selfDeconstructor : MonoBehaviour {
	public float time;
	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {
		Debug.Log ("started" + Time.time);
		StartCoroutine( wait ());
		Debug.Log ("ended" + Time.time);


	}
	IEnumerator wait()
	{			
		// ... pause briefly
		yield return new WaitForSeconds(time);
		Destroy (gameObject);
	}
}

/*public class delayAsync{


	public delayAsync(float delayTime)
	{

	}

	~delayAsync(){
				t.Abort ();
	}


}*/
