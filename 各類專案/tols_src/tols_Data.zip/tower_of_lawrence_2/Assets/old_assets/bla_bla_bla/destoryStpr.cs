﻿using UnityEngine;
using System.Collections;

public class destoryStpr : MonoBehaviour {
	public GameObject spear;
	public static bool changeDirection;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		try{
		if (Input.GetKey ("f")) {
				if(!changeDirection)
				{
			GameObject g = (GameObject)GameObject.Instantiate (spear);
			Vector3 v = g.transform.position;
			v.y = gameObject.transform.position.y + 1;
			v.x = gameObject.transform.position.x + 3;
			v.z = gameObject.transform.position.z;
			g.transform.position = v;
					g.BroadcastMessage("changeDirectionRight");
				}
				else
				{
					GameObject g = (GameObject)GameObject.Instantiate (spear);
					Vector3 v = g.transform.position;
					v.y = gameObject.transform.position.y + 1;
					v.x = gameObject.transform.position.x - 3;
					v.z = gameObject.transform.position.z;
					g.transform.position = v;
					g.BroadcastMessage("changeDirectionLeft");
				}
		}
		}catch(UnityException e){
				}
	}
}
