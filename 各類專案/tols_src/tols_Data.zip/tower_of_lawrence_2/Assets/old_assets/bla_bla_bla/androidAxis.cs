﻿using UnityEngine;
using System.Collections;

public class androidAxis : MonoBehaviour {
	public string q_axis;
	public string space_axis;	
	public GameObject spear;
	public float jumpHard;
	public static bool changeDirection;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		try{
			bool jumping = false;
			bool isAttacking = false;
			if ( Input.GetTouch (0).phase == TouchPhase.Stationary) {
				if(Input.GetTouch(0).position.x > Screen.width / 2)
				{
					throwSpear();
				}
				else{
					jump();jumping = true;
				}
			}

			//the second finger to touch(double finger axis
			if ( Input.GetTouch (1).phase == TouchPhase.Stationary) {
				if(Input.GetTouch(1).position.x > Screen.width / 2)
				{
					throwSpear();
				}
				else{
					if(!jumping)jump();
				}
			}
		}catch(UnityException e){
				}
	}
	void jump()
	{
		GetComponent<Rigidbody2D>().velocity = new Vector2 (0, jumpHard);
	}
	void throwSpear()
	{
		if (!changeDirection) {
						GameObject g = (GameObject)GameObject.Instantiate (spear);
						Vector3 v = g.transform.position;
						v.y = gameObject.transform.position.y + 1;
						v.x = gameObject.transform.position.x + 3;
						v.z = gameObject.transform.position.z;
						g.transform.position = v;
			g.BroadcastMessage("changeDirectionRight");
		} else {
			GameObject g = (GameObject)GameObject.Instantiate (spear);
			Vector3 v = g.transform.position;
			v.y = gameObject.transform.position.y + 1;
			v.x = gameObject.transform.position.x - 3;
			v.z = gameObject.transform.position.z;
			g.transform.position = v;
			g.BroadcastMessage("changeDirectionLeft");
		}
	}
}
