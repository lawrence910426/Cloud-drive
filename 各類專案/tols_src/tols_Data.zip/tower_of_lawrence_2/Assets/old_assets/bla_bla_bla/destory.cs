﻿using UnityEngine;
using System.Collections;

public class destory : MonoBehaviour {

	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
	
	}
	void OnCollisionEnter2D(Collision2D collider)
	{
		if (collider.collider.gameObject.tag != "gnd") {
						GameObject.Destroy (collider.collider.gameObject);
				}
	}
}
