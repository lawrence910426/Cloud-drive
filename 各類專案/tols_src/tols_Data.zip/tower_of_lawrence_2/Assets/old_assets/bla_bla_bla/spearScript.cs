using UnityEngine;
using System.Collections;

public class spearScript : MonoBehaviour {
	public int deltaTimes;
	public GameObject explode;
	bool changeDirection;
	// Use this for initialization
	void Start () {
		
	}
	void changeDirectionLeft()
	{
		changeDirection = true;
	}
	void changeDirectionRight()
	{
		changeDirection = false;
	}
	// Update is called once per frame
	void Update () {
		if(!changeDirection)
			gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2 (Time.deltaTime * deltaTimes, 0);
		else
			gameObject.GetComponent<Rigidbody2D>().velocity = new Vector2 (- Time.deltaTime * deltaTimes, 0);
	}
	void OnTriggerEnter2D(Collider2D c)
	{
		if (c.gameObject.tag != "unDestroyAbleMob") {
			GameObject g = (GameObject)GameObject.Instantiate (explode);
			g.transform.position = c.gameObject.transform.position;
			Destroy (c.gameObject);
		}
	}
}
