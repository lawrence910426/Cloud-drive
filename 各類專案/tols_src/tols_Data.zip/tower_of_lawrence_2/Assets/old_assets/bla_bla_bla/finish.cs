﻿using UnityEngine;
using System.Collections;

public class finish : MonoBehaviour {
	public GameObject locker;
	public int waitSecBack;
	public string nextScene;
	public static string next_scene;
	bool finishSoundStart = false;bool startCountDown = false;
	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void OnCollisionEnter2D (Collision2D c) {
		if (c.gameObject.tag == "Player") {
			if(finishSoundStart == false)
			{
				GameObject.Instantiate(locker, gameObject.transform.position ,locker.transform.rotation);
				finishSoundStart = true;
			}
		}
	}

	private float startTime;
	void Update()
	{
		if (finishSoundStart && startCountDown == false) {
						startTime = Time.time;
						startCountDown = true;
		}
		if(startCountDown)
		{

			if(startTime + waitSecBack < Time.time)
			{
				doFinishThing();
			}
		}
	}

    void doFinishThing()
	{
		next_scene = nextScene;
		Application.LoadLevel ("finishScene");


	}

}

