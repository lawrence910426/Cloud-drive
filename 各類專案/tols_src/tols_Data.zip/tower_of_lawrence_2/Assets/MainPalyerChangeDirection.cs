﻿using UnityEngine;
using System.Collections;

public class MainPalyerChangeDirection : MonoBehaviour {
	static bool faceToRight = true;
	Quaternion regularRotation;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		
	}
	void OnCollisionEnter2D(Collision2D collision)
	{
		if (collision.gameObject.tag == "Player") {

			if (faceToRight) {
				faceToRight = false;
				regularRotation = collision.transform.rotation;
				collision.transform.rotation = GameObject.FindGameObjectWithTag ("180").transform.rotation;
				moving.changeDirection = true;
				androidAxis.changeDirection = true;
				destoryStpr.changeDirection = true;
			}
			else{

				faceToRight = true;

				collision.transform.rotation = GameObject.FindGameObjectWithTag ("0").transform.rotation;//just unable ro reset mainplayer.roatation back to 0,0,0
				moving.changeDirection = false;
				androidAxis.changeDirection = false;
				destoryStpr.changeDirection = false;
			}
		}
	}
}
