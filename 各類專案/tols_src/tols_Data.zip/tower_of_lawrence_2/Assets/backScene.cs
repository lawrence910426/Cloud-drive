﻿using UnityEngine;
using System.Collections;

public class backScene : MonoBehaviour {


	// Use this for initialization
	void Start () {
		if(StageManager.GetAvailableStage() < System.Convert.ToInt32( finish.next_scene))
			StageManager.WriteAvailableStage (System.Convert.ToInt32( finish.next_scene));
	}
	
	// Update is called once per frame
	void Update () 
	{try{

			if (Input.GetKey( "w"))
						next ();
			if ( Input.GetKey("q") )
						Application.LoadLevel ("Re_start_scene");


			Touch t =	Input.GetTouch(0);	
			if (t.position.x < Screen.width / 2 )
				Application.LoadLevel ("Re_start_scene");
			if (t.position.x > Screen.width / 2)
					next ();
		}catch(UnityException e){}
	}
	void next()
	{
		Debug.Log (finish.next_scene);
		Application.LoadLevel (finish.next_scene);

	}
}
