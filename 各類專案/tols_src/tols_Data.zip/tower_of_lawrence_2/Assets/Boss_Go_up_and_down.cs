﻿using UnityEngine;
using System.Collections;

public class Boss_Go_up_and_down : MonoBehaviour {
	public int deltaTimes;
	bool isGoingDown = true;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (isGoingDown) {
						Vector3 before = gameObject.transform.position;
						before.y -= deltaTimes * Time.deltaTime;
						gameObject.transform.position = before;
		} else {
			Vector3 before = gameObject.transform.position;
			before.y += deltaTimes * Time.deltaTime;
			gameObject.transform.position = before;

		}
	}
	void OnCollisionEnter2D(Collision2D collision)
	{
		//if (collision.gameObject.tag != "Player" && collision.gameObject.tag != "spear") {
			if(isGoingDown)isGoingDown = false;
			else isGoingDown = true;
		//}

	}
}
