﻿using UnityEngine;
using System.Collections;

public class diedScript : MonoBehaviour {
	public int waitTimes;
	// Use this for initialization
	void Start () {

	}
	int i;

	void Update () {
		Debug.Log (i);
		if (++i > waitTimes) {

						Application.LoadLevel ("Re_start_scene");
				}
	}
    
}
