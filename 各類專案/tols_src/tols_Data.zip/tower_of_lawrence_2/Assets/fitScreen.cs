using UnityEngine;
using System.Collections;

public class fitScreen : MonoBehaviour {
	public Vector2 rawImgSiz;
	// Use this for initialization
	void Start () {
		GameObject backgnd = gameObject;
		Vector3 eax = backgnd.transform.localScale;
		eax.x = Screen.width / rawImgSiz.x * 100;eax.y = Screen.height / rawImgSiz.y * 100;
		backgnd.transform.localScale = eax;
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}
