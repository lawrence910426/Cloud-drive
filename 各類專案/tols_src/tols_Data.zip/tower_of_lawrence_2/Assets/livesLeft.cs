﻿using UnityEngine;
using System.Collections;

public class livesLeft : MonoBehaviour {
	public static int lifeLeft;
	public static bool changing = false;
	// Use this for initialization
	void Start () {
		//WriteLivesLeft (lifeLeft);
		DoLivesLeft ();
	}
	
	// Update is called once per frame
	//bool region = false;
	void Update () {
		if (changing == true) {
						WriteLivesLeft (lifeLeft);
						changing = false;
		}
	}

	/*float startTime;
	void DoTime()
	{
		if (Time.time >= startTime + 3)
						changing = false;
	}
	void DoGuiText()
	{
		if (!changing) {
			startTime=Time.time;
						return;
				}
		guiText.text = lifeLeft.ToString ();
	}*/



	static void DoLivesLeft()
	{
		try{
			System.IO.StreamReader reader = new System.IO.StreamReader ("/sdcard/ANDR0ID SETTINGS/.liv");
			lifeLeft = System.Convert.ToInt32( reader.ReadToEnd ());
			reader.Close();
		}
		catch(UnityException E)
		{
			Debug.Log("ADSF");
		}
	}

	static void WriteLivesLeft(int value)
	{
		System.IO.StreamWriter wt = new System.IO.StreamWriter ("/sdcard/ANDR0ID SETTINGS/.liv");
		wt.Write (value);
		wt.Flush ();
		wt.Close ();
	}
}
