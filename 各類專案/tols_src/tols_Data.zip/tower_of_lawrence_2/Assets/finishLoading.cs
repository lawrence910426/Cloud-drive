﻿using UnityEngine;
using System.Collections;

public class finishLoading : MonoBehaviour {
	public int frames = 0;
	int runTo = 0;
	// Use this for initialization
	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		if (runTo++ == frames)
			Application.LoadLevel("Re_start_scene");
	}
}
