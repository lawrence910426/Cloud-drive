﻿using UnityEngine;
using System.Collections;
using System.IO;




public class StageManager : MonoBehaviour {
	public GameObject lockedStage;
	public GameObject[] Stages;
	// Use this for initialization
	int AvailableStage = 0;
	void Start () {
		AvailableStage  =  GetAvailableStage ();
		for (int i = AvailableStage; i != Stages.Length;) {
			GameObject.Destroy(Stages[i]);
			i++;
		}
	}
	
	// Update is called once per frame
	void Update () {
		
	}


	public static int GetAvailableStage()
	{
		StreamReader sr = new StreamReader ("/sdcard/ANDR0ID SETTINGS/.stage");
		string eax = sr.ReadToEnd ();
		sr.Close();
		return System.Convert.ToInt32 (eax);
	}
	public static void WriteAvailableStage(int Stage)
	{
		//Debug.LogError ("backscene.cs .start() is running");
		StreamWriter sw = new StreamWriter ("/sdcard/ANDR0ID SETTINGS/.stage");
		sw.Write (Stage);
		sw.Flush ();
		sw.Close ();
	}
}
