﻿using UnityEngine;
using System.Collections;

public class BGM : MonoBehaviour{

    public	 AudioClip[] soundEffect;
	int on = 0;
   /*public static	bool enableBgm = true;*/
	// Use this for initialization
	void Start () {

	}
	
	// Update is called once per frame
	void Update () {
		//Debug.Log(BGM.enableBgm);

		/*NGUITools.PlaySound (soundEffect [3]);*/	/*if (enableBgm) {*/
						if (!GetComponent<AudioSource>().isPlaying) {
								if (on == soundEffect.Length) {
										on = 0;
								}
								GetComponent<AudioSource>().clip = soundEffect [on++];
			GetComponent<AudioSource>().Play();
								
						}
		/* }else {
						audio.clip = null;
				}*/
	}
		/*public void stopBgm()
		{enableBgm = false;}
		public void startBgm(){
				enableBgm = true;
		}*/
		




}
