﻿using UnityEngine;
using System.Collections;

public class weapon_module : MonoBehaviour {
	public static string weaponName = "spear";
	static bool changingWeapon;
	static int on = 0;
	// Use this for initialization

	void Start () {
	
	}
	
	// Update is called once per frame
	void Update () {
		//weaponName;
		if (changingWeapon) {
						if (on == weaponName.Length)
				changingWeapon = false;
						GetComponent<GUIText>().text = "USING " + weaponName.ToUpper ().Remove (on++);
		}
	}

	static void changWeapon(string name)
	{
		weaponName = name;
		changingWeapon = true;
		on = 0;
	}

}
