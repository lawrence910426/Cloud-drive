﻿using UnityEngine;
using System.Collections;
using System.Security;
using System.Security.Cryptography;

/*
 * 
 * 
 * 
 * 
 * NOT FINISHED YET
 * 
 * 
 * 
 * 
 */
public class lifeModule
{
	public lifeModule()
	{


	}
}


class life
{
	short livesLeft = 0;


}

class cryptKey
{
	public byte[] Key;
	public cryptKey()
	{
		string rawKey = "H0w 1s your finding key pr0ject going on?You're very close to the end.Don't worry.It's two keys to calculate the final key.This is key1.";

		string cryptKeysKey = "It's seems you found key2.If you found key1 ,congraduation!1f you don't,keep working on it.";

		Key = cryption (System.Text.Encoding.ASCII.GetBytes (rawKey), System.Text.Encoding.ASCII.GetBytes (cryptKeysKey));
	}
	public static byte[] cryption(byte[] raw,byte[] key)
	{
		Aes aesObject = Aes.Create ();
		aesObject.Key = key;
		aesObject.GenerateIV ();
		ICryptoTransform cryptor = aesObject.CreateEncryptor ();

		System.IO.MemoryStream reader = new System.IO.MemoryStream();
		CryptoStream cryptStream = new CryptoStream (reader, cryptor, System.Security.Cryptography.CryptoStreamMode.Read);
		byte[] ret = new byte[reader.Length];
		for (int i = 0; i != reader.Length; ) {
			ret[i++] = (byte)reader.ReadByte ();
		}
		return ret;
	}

	public byte[] GetKey()
	{
		return Key;
	}
}