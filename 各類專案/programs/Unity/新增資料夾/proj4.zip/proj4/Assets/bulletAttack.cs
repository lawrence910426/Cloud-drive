﻿using UnityEngine;
using System.Collections;

public class bulletAttack : MonoBehaviour
{

    // Use this for initialization
    public Vector2 loc;
    void Start()
    {
        //SpriteRenderer sr = gameObject.GetComponent<SpriteRenderer>(); 
        ////ship
        //SpriteRender.haha;
    }

    // Update is called once per frame
    void Update()
    {



        Update();
    }
}
