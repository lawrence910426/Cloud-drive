﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        For i = 0 To DataGridView1.Rows.Count - 2
            Dim up = 0, down = 0, gcd = 0
            Dim b = Int32.Parse(DataGridView1.Rows(i).Cells("a").Value.ToString), a = Int32.Parse(DataGridView1.Rows(i).Cells("b").Value.ToString)
            Dim y = Int32.Parse(DataGridView1.Rows(i).Cells("c").Value.ToString), x = Int32.Parse(DataGridView1.Rows(i).Cells("d").Value.ToString)
            Select Case DataGridView1.Rows(i).Cells("operator").Value.ToString
                Case "+"
                    up = b * x + a * y : down = a * x
                Case "-"
                    up = b * x - a * y : down = a * x
                Case "*"
                    up = b * y : down = a * x
                Case "/"
                    up = b * x : down = a * y
            End Select
            gcd = Me.gcd(up, down) : up /= gcd : down /= gcd
            If down = 1 Then
                DataGridView1.Rows(i).Cells("ans").Value = up.ToString
            Else
                DataGridView1.Rows(i).Cells("ans").Value = up.ToString + "/" + down.ToString
            End If
        Next
    End Sub

    Function gcd(ByVal a As Integer, ByVal b As Integer)    'Not considering about negative numbers.
        If a = 0 Then Return b
        If b = 0 Then Return a
        If a > b Then Return gcd(a Mod b, b)
        If a < b Then Return gcd(a, b Mod a)
        If a = b Then Return a
    End Function

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.Columns.Add("a", "a") : DataGridView1.Columns.Add("b", "b") : DataGridView1.Columns.Add("c", "c") : DataGridView1.Columns.Add("d", "d") : DataGridView1.Columns.Add("operator", "operator")
        DataGridView1.Columns.Add("ans", "ans")
    End Sub
End Class
