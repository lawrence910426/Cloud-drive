﻿Public Class Form1
    Function make_cards()
        Dim length As Integer = Val(TextBox1.Text)
        Dim data(length) As Integer
        Dim used(52) As Boolean
        For i = 1 To length
            Dim chosen = Int(New Random().NextDouble * 52)
            If used(chosen) Then
                i -= 1
            Else
                data(i) = chosen
                used(chosen) = True
            End If
        Next
        Return data
    End Function

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        DataGridView1.Rows.Clear()
        Dim data() As Integer = make_cards()
        Dim size_order = "AKQJ098765432", encode_order = "A234567890JQK"
        Dim color() As String =
        {
            System.Text.Encoding.UTF8.GetString({226, 153, 160}),
            System.Text.Encoding.UTF8.GetString({226, 153, 165}),
            System.Text.Encoding.UTF8.GetString({226, 153, 166}),
            System.Text.Encoding.UTF8.GetString({226, 153, 163})
        }

        For i = 1 To data.Length / 2
            DataGridView1.Rows.Add()
            Dim c1 = Int(data(i * 2 - 1) / 13), c2 = Int(data(i * 2) / 13)
            Dim n1 = encode_order.Chars(data(i * 2 - 1) Mod 13), n2 = encode_order.Chars(data(i * 2) Mod 13)
            Dim msg = ""
            If InStr(size_order, n1) = InStr(size_order, n2) Then msg = "even"
            If InStr(size_order, n1) < InStr(size_order, n2) Then msg = "left win"
            If InStr(size_order, n1) > InStr(size_order, n2) Then msg = "right win"

            DataGridView1.Rows(i - 1).Cells("first").Value = color(c1) + n1.ToString().Replace("0", "10")
            DataGridView1.Rows(i - 1).Cells("second").Value = color(c2) + n2.ToString().Replace("0", "10")
            DataGridView1.Rows(i - 1).Cells("msg").Value = msg
        Next
    End Sub

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.Columns.Add("first", "first") : DataGridView1.Columns.Add("second", "second") : DataGridView1.Columns.Add("msg", "msg")
    End Sub
End Class
