﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        for_style()
        while_front_style()
        while_end_style()
    End Sub

    Sub for_style()
        For i = 0 To TextBox1.Text.Length \ 2
            If TextBox1.Text.ElementAt(i) <> TextBox1.Text.ElementAt(TextBox1.Text.Length - i - 1) Then
                MsgBox("Is not a palindrome")
                Return
            End If
        Next
        MsgBox("Is a palindrome")
    End Sub

    Sub while_front_style()
        Dim i As Integer = 0
        Do While i < TextBox1.Text.Length \ 2
            If TextBox1.Text.ElementAt(i) <> TextBox1.Text.ElementAt(TextBox1.Text.Length - i - 1) Then
                MsgBox("Is not a palindrome")
                Return
            End If
            i += 1
        Loop
        MsgBox("Is a palindrome")
    End Sub

    Sub while_end_style()
        Dim i As Integer = 0
        Do
            If TextBox1.Text.ElementAt(i) <> TextBox1.Text.ElementAt(TextBox1.Text.Length - i - 1) Then
                MsgBox("Is not a palindrome")
                Return
            End If
            i += 1
        Loop While i <= TextBox1.Text.Length \ 2
        MsgBox("Is a palindrome")
    End Sub
End Class
