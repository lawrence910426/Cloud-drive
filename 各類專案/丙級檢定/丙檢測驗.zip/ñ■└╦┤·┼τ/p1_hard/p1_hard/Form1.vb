﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        DataGridView1.Sort(DataGridView1.Columns(0), System.ComponentModel.ListSortDirection.Ascending)
        For i = 0 To DataGridView1.Rows.Count - 2
            Dim id = DataGridView1.Rows(i).Cells("id").Value.ToString
            Dim gen = DataGridView1.Rows(i).Cells("gender").Value.ToString
            If Not check_format(id, gen) Then
                DataGridView1.Item(3, i).Value = "FORMAT ERROR"
            ElseIf Not (id.ElementAt(1) = "1" And gen = "MALE") Or (id.ElementAt(1) = "2" And gen = "FEMALE") Then
                DataGridView1.Item(3, i).Value = "GENDER ERROR"
            ElseIf Not check_sum(id) Then
                DataGridView1.Item(3, i).Value = "CHKSUM ERROR"
            Else
                DataGridView1.Item(3, i).Value = "ACCEPTED"
            End If
        Next
    End Sub

    Function check_format(ByVal id As String, ByVal gender As String)
        If Not id.Length = 10 Then Return False
        If Not (Asc("A") <= Asc(id.ElementAt(0)) And Asc(id.ElementAt(0)) <= Asc("Z")) Then Return False
        For i = 1 To 9
            If Not (Asc("0") <= Asc(id.ElementAt(i)) And Asc(id.ElementAt(i)) <= Asc("9")) Then Return False
        Next
        If Not ((gender = "MALE") Or (gender = "FEMALE")) Then Return False
        Return True
    End Function

    Function check_sum(ByVal id As String)
        Dim code = InStr("ABCDEFGHJKLMNPQRSTUVXYWZIO", id.ElementAt(0)) + 9
        Dim sum = code \ 10 + (code Mod 10) * 9 + Int32.Parse(id.ElementAt(9))
        For i = 1 To 8
            sum += Int32.Parse(id.ElementAt(i)) * (9 - i)
        Next
        Return sum Mod 10 = 0
    End Function

    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        DataGridView1.Columns.Add("id", "id") : DataGridView1.Columns.Add("gender", "gender") : DataGridView1.Columns.Add("name", "name") : DataGridView1.Columns.Add("status", "status")
    End Sub
End Class
