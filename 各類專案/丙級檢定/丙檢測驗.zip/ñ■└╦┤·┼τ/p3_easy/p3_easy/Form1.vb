﻿Public Class Form1
    Dim max_value = 1024
    Dim prime_arr(max_value) As Boolean
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        prime_arr(1) = False
        prime_arr(2) = True

        while_end_style()
    End Sub

    Sub for_style()
        For i = 3 To max_value
            prime_arr(i) = True
            For j = 2 To i - 1
                If i Mod j = 0 Then
                    prime_arr(i) = False
                    Exit For
                End If
            Next
        Next
    End Sub

    Sub while_front_style()
        Dim i = 3, j = 0
        Do While i <= max_value
            j = 2
            Do While j <= i - 1
                If i Mod j = 0 Then
                    prime_arr(i) = True
                    Exit Do
                End If
                j += 1
            Loop
            i += 1
        Loop
    End Sub

    Sub while_end_style()
        Dim i = 3, j = 0
        Do
            j = 2
            Do
                If i Mod j = 0 Then
                    prime_arr(i) = True
                    Exit Do
                End If
                j += 1
            Loop While j <= i - 1
            i += 1
        Loop While i <= max_value
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        MsgBox(If(prime_arr(Val(TextBox1.Text)), "is a prime", "is not a prime"))
    End Sub
End Class
