﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.w1 = New System.Windows.Forms.TextBox()
        Me.h1 = New System.Windows.Forms.TextBox()
        Me.w2 = New System.Windows.Forms.TextBox()
        Me.h2 = New System.Windows.Forms.TextBox()
        Me.w3 = New System.Windows.Forms.TextBox()
        Me.h3 = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'w1
        '
        Me.w1.Location = New System.Drawing.Point(129, 37)
        Me.w1.Name = "w1"
        Me.w1.Size = New System.Drawing.Size(100, 22)
        Me.w1.TabIndex = 0
        Me.w1.Text = "weight"
        '
        'h1
        '
        Me.h1.Location = New System.Drawing.Point(23, 37)
        Me.h1.Name = "h1"
        Me.h1.Size = New System.Drawing.Size(100, 22)
        Me.h1.TabIndex = 1
        Me.h1.Text = "height"
        '
        'w2
        '
        Me.w2.Location = New System.Drawing.Point(129, 65)
        Me.w2.Name = "w2"
        Me.w2.Size = New System.Drawing.Size(100, 22)
        Me.w2.TabIndex = 2
        '
        'h2
        '
        Me.h2.Location = New System.Drawing.Point(23, 65)
        Me.h2.Name = "h2"
        Me.h2.Size = New System.Drawing.Size(100, 22)
        Me.h2.TabIndex = 3
        '
        'w3
        '
        Me.w3.Location = New System.Drawing.Point(129, 93)
        Me.w3.Name = "w3"
        Me.w3.Size = New System.Drawing.Size(100, 22)
        Me.w3.TabIndex = 4
        '
        'h3
        '
        Me.h3.Location = New System.Drawing.Point(23, 93)
        Me.h3.Name = "h3"
        Me.h3.Size = New System.Drawing.Size(100, 22)
        Me.h3.TabIndex = 5
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(145, 121)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 23)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "Button1"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(284, 261)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.h3)
        Me.Controls.Add(Me.w3)
        Me.Controls.Add(Me.h2)
        Me.Controls.Add(Me.w2)
        Me.Controls.Add(Me.h1)
        Me.Controls.Add(Me.w1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents w1 As TextBox
    Friend WithEvents h1 As TextBox
    Friend WithEvents w2 As TextBox
    Friend WithEvents h2 As TextBox
    Friend WithEvents w3 As TextBox
    Friend WithEvents h3 As TextBox
    Friend WithEvents Button1 As Button
End Class
