﻿Public Class Form1
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim a, b, c As Single
        a = Val(w1.Text) / Val(h1.Text) / Val(h1.Text) * 10000
        a = Math.Round(a)

        b = Val(w2.Text) / Val(h2.Text) / Val(h2.Text) * 10000
        b = Math.Round(b)

        c = Val(w3.Text) / Val(h3.Text) / Val(h3.Text) * 10000
        c = Math.Round(c)

        a = Math.Min(a, Math.Min(b, c))
        If 20 <= a And a < 25 Then
            MsgBox("minimum weight: " + a.ToString + " ,OK")
        Else
            MsgBox("minimum weight: " + a.ToString + " ,not OK")
        End If
    End Sub
End Class
