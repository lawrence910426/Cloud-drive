﻿Public Class Form1
    Sub swap(ByRef a, ByRef b)
        Dim eax = a
        a = b
        b = eax
    End Sub
    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load
        Dim i() As Integer = {1, 3, 5, 7, 9, 11, 13}
        Dim m(5) As Integer
        For j = 0 To 5
            m(j) = i(j)
        Next
        MsgBox(m(m(1) + 2) + 3)
    End Sub
End Class
