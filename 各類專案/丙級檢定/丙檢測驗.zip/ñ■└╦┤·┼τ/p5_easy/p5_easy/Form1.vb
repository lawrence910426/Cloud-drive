﻿Public Class Form1
    Dim matr_a = {{1, 2}, {3, 4}}
    Dim matr_b = {{5, 4}, {8, 7}}
    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        while_front_style()

        For i = 0 To 1
            For j = 0 To 1
                MsgBox("i:" + i.ToString + " j:" + j.ToString + " value:" + matr_a(i, j).ToString)
            Next
        Next
    End Sub

    Sub for_style()
        For i = 0 To 1
            For j = 0 To 1
                matr_a(i, j) += matr_b(i, j)
            Next
        Next
    End Sub

    Sub while_front_style()
        Dim i = 0, j = 0
        Do While i <= 1
            j = 0
            Do While j <= 1
                matr_a(i, j) += matr_b(i, j)
                j += 1
            Loop
            i += 1
        Loop
    End Sub

    Sub while_end_style()
        Dim i = 0, j = 0
        Do
            j = 0
            Do
                matr_a(i, j) += matr_b(i, j)
                j += 1
            Loop While j <= 1
            i += 1
        Loop While i <= 1
    End Sub
End Class
