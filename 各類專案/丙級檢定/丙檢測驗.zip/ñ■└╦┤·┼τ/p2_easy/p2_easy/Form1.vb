﻿Public Class Form1
    Dim size As Integer = 9

    Private Sub Button3_Click(sender As Object, e As EventArgs) Handles Button3.Click
        For i = 1 To size
            For j = 1 To i
                RichTextBox1.Text += j.ToString()
            Next
            RichTextBox1.Text += vbNewLine
        Next
    End Sub

    Private Sub Button2_Click(sender As Object, e As EventArgs) Handles Button2.Click
        Dim i As Integer = 1 : Dim j As Integer = 1
        Do While i <= size
            j = 1
            Do While j <= i
                RichTextBox1.Text += j.ToString()
                j += 1
            Loop
            i += 1
            RichTextBox1.Text += vbNewLine
        Loop
    End Sub

    Private Sub Button1_Click(sender As Object, e As EventArgs) Handles Button1.Click
        Dim i As Integer = 1 : Dim j As Integer = 1
        Do
            j = 1
            Do
                RichTextBox1.Text += j.ToString()
                j += 1
            Loop While j <= i
            i += 1
            RichTextBox1.Text += vbNewLine
        Loop While i <= size
    End Sub
End Class
